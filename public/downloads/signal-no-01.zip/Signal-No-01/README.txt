SIGNAL NO. 01
Minimal-tech wallpapers by mitaa.dev

Thank you for choosing Signal No. 01. This pack contains six original
wallpaper designs, each supplied in four high-resolution formats.

INCLUDED DESIGNS

01. Circuit Drift
02. Quiet Array
03. Copper Pulse
04. Open Circuit
05. Phase Field
06. Signal Bloom

FORMATS

- 5120 x 2880 px (16:9 desktop)
- 5120 x 3200 px (16:10 desktop)
- 5120 x 2160 px (21:9 ultrawide)
- 1440 x 3200 px (mobile)

All wallpapers are high-quality sRGB JPG files without watermarks.

INSTALLATION

Desktop: open your system wallpaper settings, choose the matching aspect
ratio, and use Fill or Crop only if your display has a different ratio.

Mobile: save the mobile version to your photo library, open your wallpaper
settings, and position it with the clock and icons visible.

License terms are included in LICENSE.txt.

mitaa.dev
