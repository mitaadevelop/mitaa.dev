Essay — LaTeX template by mitaa.dev

CONTENTS
  main.tex         the text; fill in your details at the top
  setup.tex        the styling: font, colour and margins
  references.bib   your sources, in APA 7 style

IN OVERLEAF
  Go to overleaf.com, choose New Project > Upload Project and select
  this ZIP file. Overleaf compiles it straight away.

LOCALLY
  Install MacTeX, TeX Live or MiKTeX and run:
    latexmk -pdf main.tex
  latexmk runs Biber for the references by itself.

LICENSE
  Free to use and adapt for your own essays, reports and research,
  including graded and published work. No attribution needed. Please do
  not resell the templates or offer them for download elsewhere.

A two-page LaTeX cheat sheet and more templates:
  https://mitaa.dev/shop/latex-templates
